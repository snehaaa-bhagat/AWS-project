import boto3
import os
import logging
import time
from botocore.exceptions import ClientError

def get_s3_client():
    return boto3.client(
        's3',
        aws_access_key_id=os.environ.get('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY'),
        region_name=os.environ.get('AWS_REGION', 'us-east-1')
    )

def get_logs_client():
    return boto3.client(
        'logs',
        aws_access_key_id=os.environ.get('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.environ.get('AWS_SECRET_ACCESS_KEY'),
        region_name=os.environ.get('AWS_REGION', 'us-east-1')
    )

def upload_file_to_s3(file_obj, object_name):
    """Upload a file to an S3 bucket"""
    s3_client = get_s3_client()
    bucket_name = os.environ.get('S3_BUCKET_NAME')
    try:
        s3_client.upload_fileobj(file_obj, bucket_name, object_name)
        return True
    except ClientError as e:
        logging.error(e)
        return False

def generate_presigned_url(object_name, expiration=3600):
    """Generate a presigned URL to share an S3 object"""
    s3_client = get_s3_client()
    bucket_name = os.environ.get('S3_BUCKET_NAME')
    try:
        response = s3_client.generate_presigned_url('get_object',
                                                    Params={'Bucket': bucket_name,
                                                            'Key': object_name},
                                                    ExpiresIn=expiration)
    except ClientError as e:
        logging.error(e)
        return None
    return response

def delete_s3_object(object_name):
    """Delete an object from an S3 bucket"""
    s3_client = get_s3_client()
    bucket_name = os.environ.get('S3_BUCKET_NAME')
    try:
        s3_client.delete_object(Bucket=bucket_name, Key=object_name)
        return True
    except ClientError as e:
        logging.error(e)
        return False

def log_audit_event(action, username, details=""):
    """Log an audit event to AWS CloudWatch"""
    logs_client = get_logs_client()
    log_group = os.environ.get('CLOUDWATCH_LOG_GROUP', 'SecureFileStorageLogs')
    log_stream = 'AuditLogStream'
    
    # Try to create group/stream if they don't exist (basic handling)
    try:
        logs_client.create_log_stream(logGroupName=log_group, logStreamName=log_stream)
    except logs_client.exceptions.ResourceAlreadyExistsException:
        pass
    except Exception as e:
        # Ignore errors if CloudWatch is not fully set up or permissions lack
        print(f"CloudWatch setup error (ignore if local dev without CW): {e}")

    timestamp = int(round(time.time() * 1000))
    message = f"[{action}] User: {username} | {details}"
    
    try:
        logs_client.put_log_events(
            logGroupName=log_group,
            logStreamName=log_stream,
            logEvents=[
                {
                    'timestamp': timestamp,
                    'message': message
                }
            ]
        )
    except Exception as e:
        logging.error(f"Failed to write to CloudWatch: {e}")
