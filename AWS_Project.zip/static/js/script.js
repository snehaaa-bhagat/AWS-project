// Initialize Bootstrap tooltips
document.addEventListener('DOMContentLoaded', function () {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // File Upload Drag and Drop logic
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const fileNameDisplay = document.getElementById('fileNameDisplay');

    if (dropZone && fileInput) {
        // Handle drag events
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, preventDefaults, false);
        });

        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }

        ['dragenter', 'dragover'].forEach(eventName => {
            dropZone.addEventListener(eventName, highlight, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, unhighlight, false);
        });

        function highlight(e) {
            dropZone.classList.add('dragover');
        }

        function unhighlight(e) {
            dropZone.classList.remove('dragover');
        }

        // Handle drop event
        dropZone.addEventListener('drop', handleDrop, false);

        function handleDrop(e) {
            const dt = e.dataTransfer;
            const files = dt.files;

            if (files.length > 0) {
                fileInput.files = files;
                updateFileNameDisplay(files[0].name);
            }
        }

        // Handle normal file input change
        fileInput.addEventListener('change', function() {
            if (this.files.length > 0) {
                updateFileNameDisplay(this.files[0].name);
            }
        });

        function updateFileNameDisplay(name) {
            if (fileNameDisplay) {
                fileNameDisplay.textContent = 'Selected: ' + name;
                fileNameDisplay.classList.remove('d-none');
            }
        }
        
        // Form submit loading state
        const uploadForm = document.getElementById('uploadForm');
        const uploadBtn = document.getElementById('uploadBtn');
        
        if (uploadForm && uploadBtn) {
            uploadForm.addEventListener('submit', function() {
                if (fileInput.files.length > 0) {
                    uploadBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Uploading...';
                    uploadBtn.disabled = true;
                }
            });
        }
    }
});

// Share link generation via AJAX
function generateShareLink(fileId) {
    fetch(`/share/${fileId}`)
        .then(response => response.json())
        .then(data => {
            if (data.url) {
                document.getElementById('shareLinkInput').value = data.url;
                const shareModal = new bootstrap.Modal(document.getElementById('shareModal'));
                shareModal.show();
                
                // Reset copy button
                const copyBtn = document.getElementById('copyLinkBtn');
                copyBtn.innerHTML = '<i class="bi bi-clipboard"></i> Copy';
                copyBtn.classList.remove('btn-success');
                copyBtn.classList.add('btn-outline-success');
            } else {
                alert('Failed to generate link: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while generating the link.');
        });
}

function copyShareLink() {
    const copyText = document.getElementById('shareLinkInput');
    copyText.select();
    copyText.setSelectionRange(0, 99999); // For mobile devices
    
    navigator.clipboard.writeText(copyText.value).then(() => {
        const copyBtn = document.getElementById('copyLinkBtn');
        copyBtn.innerHTML = '<i class="bi bi-check-lg"></i> Copied!';
        copyBtn.classList.remove('btn-outline-success');
        copyBtn.classList.add('btn-success');
        
        setTimeout(() => {
            copyBtn.innerHTML = '<i class="bi bi-clipboard"></i> Copy';
            copyBtn.classList.remove('btn-success');
            copyBtn.classList.add('btn-outline-success');
        }, 3000);
    });
}
