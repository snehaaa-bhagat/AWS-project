import os
import uuid
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from flask_bcrypt import Bcrypt
from werkzeug.utils import secure_filename
from functools import wraps
from dotenv import load_dotenv

from models import db, User, FileMetadata
from aws_utils import upload_file_to_s3, generate_presigned_url, delete_s3_object, log_audit_event

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'default-dev-key')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///secure_file_storage.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db.init_app(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- Custom Decorators ---
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != 'admin':
            flash('You do not have permission to access this page.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

# --- Routes ---

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Check if user exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.', 'danger')
            return redirect(url_for('register'))
            
        # Hash password and create user
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        # First user is admin for demo purposes
        is_first_user = User.query.count() == 0
        role = 'admin' if is_first_user else 'user'
        
        new_user = User(username=username, password_hash=hashed_password, role=role)
        db.session.add(new_user)
        db.session.commit()
        
        log_audit_event('REGISTER', username, 'User registered successfully')
        flash('Account created! You can now log in.', 'success')
        return redirect(url_for('login'))
        
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        if user and bcrypt.check_password_hash(user.password_hash, password):
            login_user(user)
            log_audit_event('LOGIN', username, 'Successful login')
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            log_audit_event('LOGIN_FAILED', username, 'Failed login attempt')
            flash('Login Unsuccessful. Please check username and password', 'danger')
            
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    log_audit_event('LOGOUT', current_user.username, 'User logged out')
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    files = FileMetadata.query.filter_by(user_id=current_user.id).all()
    return render_template('dashboard.html', files=files)

@app.route('/upload', methods=['POST'])
@login_required
def upload_file():
    if 'file' not in request.files:
        flash('No file part', 'danger')
        return redirect(url_for('dashboard'))
        
    file = request.files['file']
    if file.filename == '':
        flash('No selected file', 'danger')
        return redirect(url_for('dashboard'))
        
    if file:
        filename = secure_filename(file.filename)
        # Generate unique S3 key
        s3_key = f"{current_user.id}/{uuid.uuid4().hex}_{filename}"
        
        # Read file size
        file.seek(0, os.SEEK_END)
        file_length = file.tell()
        file.seek(0, 0)
        
        # Upload to S3
        success = upload_file_to_s3(file, s3_key)
        
        if success:
            new_file = FileMetadata(filename=filename, s3_key=s3_key, size=file_length, user_id=current_user.id)
            db.session.add(new_file)
            db.session.commit()
            log_audit_event('UPLOAD', current_user.username, f'Uploaded file {filename} to S3 ({file_length} bytes)')
            flash('File uploaded successfully', 'success')
        else:
            flash('Failed to upload file to AWS S3', 'danger')
            
    return redirect(url_for('dashboard'))

@app.route('/download/<int:file_id>')
@login_required
def download_file(file_id):
    file_record = FileMetadata.query.get_or_404(file_id)
    
    # Verify ownership or admin
    if file_record.user_id != current_user.id and current_user.role != 'admin':
        flash('Unauthorized access', 'danger')
        return redirect(url_for('dashboard'))
        
    presigned_url = generate_presigned_url(file_record.s3_key)
    if presigned_url:
        log_audit_event('DOWNLOAD', current_user.username, f'Downloaded file {file_record.filename}')
        return redirect(presigned_url)
    else:
        flash('Could not generate download link', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/share/<int:file_id>')
@login_required
def share_file(file_id):
    file_record = FileMetadata.query.get_or_404(file_id)
    
    if file_record.user_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
        
    # Generate URL valid for 24 hours
    presigned_url = generate_presigned_url(file_record.s3_key, expiration=86400)
    if presigned_url:
        log_audit_event('SHARE', current_user.username, f'Generated share link for {file_record.filename}')
        return jsonify({'url': presigned_url})
    return jsonify({'error': 'Failed to generate link'}), 500

@app.route('/delete/<int:file_id>', methods=['POST'])
@login_required
def delete_file(file_id):
    file_record = FileMetadata.query.get_or_404(file_id)
    
    if file_record.user_id != current_user.id and current_user.role != 'admin':
        flash('Unauthorized access', 'danger')
        return redirect(url_for('dashboard'))
        
    success = delete_s3_object(file_record.s3_key)
    if success:
        db.session.delete(file_record)
        db.session.commit()
        log_audit_event('DELETE', current_user.username, f'Deleted file {file_record.filename}')
        flash('File deleted successfully', 'success')
    else:
        flash('Failed to delete file from S3', 'danger')
        
    return redirect(url_for('dashboard'))

@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    users = User.query.all()
    all_files = FileMetadata.query.all()
    return render_template('admin.html', users=users, files=all_files)

# Add init_db command
@app.cli.command("init-db")
def init_db_command():
    """Create new tables."""
    db.create_all()
    print('Initialized the database.')

if __name__ == '__main__':
    with app.app_context():
        # Only creates tables if they don't exist
        db.create_all()
    app.run(debug=True)
